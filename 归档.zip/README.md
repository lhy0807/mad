# WordPress Theme MAD
MAD is a clean, unique and materialized Blogging Theme. It is responsive and support various device of different size.

It is easy to install MAD theme, and it is FREE!

##Features
+ Support latest version of WordPress
+ 100% responsive
+ Material Design
+ Clean and simple

##Installation
+ Update your WordPress as new as possible
+ Download the zip file from the git
+ Upload the zip in the dashboard then active it

##Update logs
###1.0
+ The first released version of MAD theme