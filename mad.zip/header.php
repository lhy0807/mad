<!DOCTYPE html>
<html>
<head>
	<!--设置UTF-8编码-->
	<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>"/>
	<!--设置移动端响应式设计-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
	<!--网站标题-->
	<title><?php if(is_single()){the_title();} else{bloginfo('name');} ?></title>
	<meta name="description" content="<?php bloginfo('description');?>"/>
	<!-- CSS  -->
	<link href="http://fonts.useso.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="<?php echo bloginfo('stylesheet_url');?>" type="text/css" rel="stylesheet" media="screen,projection"/>
	<?php wp_head(); do_action('wp_head');?>
</head>
<body>
  <nav role="navigation" style="margin-bottom: 40px;">
    <div class="nav-wrapper container">
      <a id="logo-container" href="<?php bloginfo('url');?>" class="brand-logo white-text"><?php bloginfo('name'); ?></a>
      <?php
    wp_nav_menu(array(
	'menu' => 'header-menu',
	'menu_class' => 'right hide-on-med-and-down',
	'theme_location' => 'header-menu',
	'link_before' => '<div style="color:#ffffff">',
	'link_after' => '</div>'
	));
      ?>
	<?php
    wp_nav_menu(array(
	'menu' => 'header-menu',
	'menu_class' => 'side-nav',
	'menu_id' => 'nav-mobile',
	'theme_location' => 'header-menu'
	));
      ?>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>