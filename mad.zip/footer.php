<footer class="page-footer">
	<?php wp_footer();?>
    <div class="container">
      <div class="row">
        <div class="col l6 s6">
          <h5 class="white-text"><?php bloginfo('name'); ?></h5>
          <p class="grey-text text-lighten-4"><?php echo bloginfo('description'); ?></p>


        </div>
        <div class="col l3 s6 offset-l3">
          <h5 class="white-text">Links</h5>
    <?php
    wp_nav_menu(array(
	'menu' => 'footer-menu',
	'menu_class' => 'white-text',
	'theme_location' => 'footer-menu',
	'link_before' => '<div style="color:#ffffff">',
	'link_after' => '</div>'
	));
      ?>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
       Theme By <a href="http://www.caseba.com">Chris Lee</a> 
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri().'/js/materialize.js';?>"></script>
  <script src="<?php echo get_stylesheet_directory_uri().'/js/init.js';?>"></script>
  </body>
</html>
<?php //LightBox?>
<?php if(is_single()):?>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/highslide/highslide.css" type="text/css" />
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/highslide/highslide.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
    hs.graphicsDir = "<?php bloginfo('template_url'); ?>/highslide/graphics/";
    hs.outlineType = "rounded-white";
    hs.dimmingOpacity = 0.8;
    hs.outlineWhileAnimating = true;
    hs.showCredits = false;
    hs.captionEval = "this.thumb.alt";
    hs.numberPosition = "caption";
    hs.align = "center";
    hs.transitions = ["expand", "crossfade"];
    hs.addSlideshow({
        interval: 5000,
        repeat: true,
        useControls: true,
        fixedControls: "fit",
        overlayOptions: {
            opacity: 0.75,
            position: "bottom center",
            hideOnMouseOut: true
 
        }
 
    });
});
</script>
<?php endif;?>
